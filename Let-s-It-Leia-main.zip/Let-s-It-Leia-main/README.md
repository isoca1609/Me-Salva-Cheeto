 <a href="#"><img src="https://komarev.com/ghpvc/?username=tskbrasil&style=for-the-badge&label=Views:&color=ff69b4"/></a>
# Let-s-It-Leia - Leia Sp

## O que é?
Script para auxiliar estudantes na resolução de quizzes de livros.

## Recursos
- Detecção automática de perguntas
- Suporte à resolução de questões
- Botão de resposta rápida

## Instruções
1. Copiar script no console
2. Usar botão "Mostrar Resposta"
3. Verificar sugestões

## Aviso
Uso exclusivamente educacional.

# Discord
<a href="https://discord.gg/DWKb32QKkJ"><img src="https://img.shields.io/static/v1?logo=discord&label=&message=Discord&color=36393f&style=flat-square" alt="Discord"></a>

# ⬆️entre⬆️

# Favoritos
```js
atualizando
```

## Criadores
iUnknownBr e 𝖲𝗇𝗈w
